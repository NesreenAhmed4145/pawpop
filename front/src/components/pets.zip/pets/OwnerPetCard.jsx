import { Link } from "react-router-dom";
import { Eye, PawPrint, Pencil, Trash2 } from "lucide-react";
import { assetUrl } from "../../utils/formatters";
import { calculateAge, HEALTH_BADGE, petName } from "../../utils/petHealth";

// كارت الحيوان في صفحة My Pets (للمالك): View Profile / Edit / Delete
export default function OwnerPetCard({ pet, health, viewTo, onEdit, onDelete }) {
  const badge = health ? HEALTH_BADGE[health.status] : null;
  const age = calculateAge(pet.BirthDate) || (pet.Age ? `${pet.Age}` : "");
  const meta = [pet.Species, pet.Breed, age, pet.Gender].filter(Boolean).join(" · ");

  return (
    <article className="group overflow-hidden rounded-2xl border border-edge bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg">
      <Link to={viewTo} className="relative block h-52 overflow-hidden bg-sand-soft">
        {pet.ImageURL ? (
          <img
            src={assetUrl(pet.ImageURL)}
            alt={petName(pet)}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <span className="flex h-full w-full items-center justify-center text-text-muted">
            <PawPrint size={48} />
          </span>
        )}
        {badge && (
          <span className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-semibold shadow-sm ${badge.cls}`}>
            {badge.label}
          </span>
        )}
      </Link>

      <div className="p-5">
        <h3 className="font-serif text-xl font-bold text-text-title">{petName(pet)}</h3>
        <p className="mt-1 min-h-5 text-sm text-text-secondary">{meta}</p>

        <div className="mt-5 flex items-center gap-2">
          <Link
            to={viewTo}
            className="flex flex-1 items-center justify-center gap-2 rounded-full bg-brand py-2.5 text-sm font-semibold text-brand-contrast transition hover:bg-brand-hover"
          >
            <Eye size={16} /> View Profile
          </Link>
          <button
            type="button"
            onClick={onEdit}
            aria-label={`Edit ${petName(pet)}`}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-edge text-text-body transition hover:bg-sand-soft"
          >
            <Pencil size={16} />
          </button>
          <button
            type="button"
            onClick={() => onDelete(pet)}
            aria-label={`Delete ${petName(pet)}`}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-edge text-danger transition hover:bg-danger-bg"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
    </article>
  );
}
