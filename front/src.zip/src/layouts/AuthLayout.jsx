import { Outlet } from 'react-router-dom';
import '../styles/auth.css';
// import logo from '../assets/logo.png';   // <-- 1) فكّي التعليق بعد ما تحطي اللوجو في src/assets

export default function AuthLayout() {
  return (
    <main className="auth-page">
      <section className="auth-card">
        {/* ======================= مكان اللوجو =======================
            حطي صورة اللوجو في src/assets/logo.png ثم:
            1) فكّي التعليق عن سطر import logo فوق
            2) استبدلي <div className="auth-logo-slot" /> بالسطر التالي:
               <img src={logo} alt="pawpop" className="auth-logo" />
        ================================================================ */}
        <div className="auth-logo-slot" />

        <Outlet />
      </section>
    </main>
  );
}
