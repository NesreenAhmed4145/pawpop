export default function Input({ label, required = false, error, hint, id, name, ...props }) {
  const inputId = id || name;
  const messageId = `${inputId}-message`;

  return (
    <div className="field">
      {label && (
        <label htmlFor={inputId} className="field-label">
          {label}
          {required && <span className="field-required"> *</span>}
        </label>
      )}
      <input
        id={inputId}
        name={name}
        className={`field-input${error ? ' field-input--error' : ''}`}
        aria-required={required}
        aria-invalid={Boolean(error)}
        aria-describedby={error || hint ? messageId : undefined}
        {...props}
      />
      {error ? (
        <p id={messageId} className="field-error">
          {error}
        </p>
      ) : hint ? (
        <p id={messageId} className="field-hint">
          {hint}
        </p>
      ) : null}
    </div>
  );
}
