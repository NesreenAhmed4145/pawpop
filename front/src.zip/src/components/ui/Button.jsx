import Spinner from './Spinner';

export default function Button({
  children,
  variant = 'primary', // primary | outline
  type = 'button',
  loading = false,
  fullWidth = false,
  disabled,
  className = '',
  ...props
}) {
  const classes = ['btn', `btn--${variant}`, fullWidth ? 'btn--full' : '', className]
    .filter(Boolean)
    .join(' ');

  return (
    <button type={type} className={classes} disabled={disabled || loading} {...props}>
      {loading && <Spinner size={16} />}
      <span>{children}</span>
    </button>
  );
}
